# MiniDC Experiment - CloudSim Plus

## Descripción General
Aplicación Java que simula un datacenter en la nube usando la biblioteca CloudSim Plus. El proyecto compara dos políticas de asignación de máquinas virtuales (VMs) y calcula métricas de rendimiento, consumo energético y disponibilidad.

## Características Principales

### Datacenter
- **2 Hosts** con las siguientes especificaciones:
  - 8 Processing Elements (PE) @ 1000 MIPS cada uno
  - 32 GB RAM (32768 MB)
  - 100,000 Mbps Bandwidth
  - 1,000,000 MB Storage
  - Modelo de potencia: PowerModelHostSimple(200W max, 100W idle)

### Máquinas Virtuales (VMs)
- **6 VMs** con especificaciones:
  - 2 PE por VM
  - 4 GB RAM (4096 MB)
  - 10,000 Mbps Bandwidth
  - 20,000 MB Storage
  - Scheduler: CloudletSchedulerTimeShared

### Cloudlets (Tareas)
- **12 Cloudlets** con longitudes variadas:
  - Patrón repetido: 15000, 25000, 40000, 60000, 80000, 120000 MIPS
  - Modelo de utilización dinámica:
    - CPU: 85%
    - RAM: 70%
    - Bandwidth: 50%

### Políticas de Asignación
1. **VmAllocationPolicySimple (First-Fit)**: Asigna VMs al primer host disponible con recursos suficientes
2. **VmAllocationPolicyRoundRobin**: Política personalizada que alterna entre hosts de forma circular

### Métricas Calculadas
- **Average Response Time** (ms): Tiempo promedio de respuesta de las cloudlets
- **Makespan** (s): Tiempo total de ejecución de todas las cloudlets
- **Energy Consumption** (kWh): Consumo energético total del datacenter
- **Availability** (%): Disponibilidad del sistema (100% sin fallos)

## Estructura del Proyecto

```
.
├── pom.xml                                    # Configuración Maven
├── src/
│   └── main/
│       └── java/
│           ├── MiniDCExperiment.java         # Clase principal con simulaciones
│           └── VmAllocationPolicyRoundRobin.java  # Política round-robin personalizada
└── .gitignore                                 # Archivos ignorados por Git
```

## Tecnologías Utilizadas
- **Java 19** (GraalVM)
- **CloudSim Plus 8.5.7** - Framework de simulación de cloud computing
- **Maven** - Gestión de dependencias y build

## Ejecución
El proyecto se ejecuta automáticamente usando el workflow "Run Simulation":
```bash
mvn exec:java -Dexec.mainClass="MiniDCExperiment" --quiet
```

## Resultados de Ejemplo
```
=== MiniDC Experiment - CloudSim Plus ===

VmAllocationPolicySimple (First-Fit): AvgResponse=165712.40 ms, Makespan=420.89 s, Energy=0.023383 kWh, Availability=100.0%
VmAllocationPolicyRoundRobin: AvgResponse=165712.40 ms, Makespan=420.89 s, Energy=0.023383 kWh, Availability=100.0%
```

## Fecha de Creación
14 de octubre de 2025
