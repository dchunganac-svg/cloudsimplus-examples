import java.util.Optional;
import org.cloudsimplus.allocationpolicies.VmAllocationPolicyAbstract;
import org.cloudsimplus.hosts.Host;
import org.cloudsimplus.vms.Vm;


public class VmAllocationPolicyRoundRobin extends VmAllocationPolicyAbstract {
    private int currentHostIndex = 0;

    @Override
    protected Optional<Host> defaultFindHostForVm(Vm vm) {
        if (getHostList().isEmpty()) {
            return Optional.empty();
        }

        int attempts = 0;
        int totalHosts = getHostList().size();

        while (attempts < totalHosts) {
            Host host = getHostList().get(currentHostIndex);
            
            if (host.isSuitableForVm(vm)) {
                currentHostIndex = (currentHostIndex + 1) % totalHosts;
                return Optional.of(host);
            }
            
            currentHostIndex = (currentHostIndex + 1) % totalHosts;
            attempts++;
        }

        return Optional.empty();
    }
}
