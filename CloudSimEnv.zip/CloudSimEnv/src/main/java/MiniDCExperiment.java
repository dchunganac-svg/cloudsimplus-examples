import org.cloudsimplus.allocationpolicies.VmAllocationPolicySimple;
import org.cloudsimplus.brokers.DatacenterBroker;
import org.cloudsimplus.brokers.DatacenterBrokerSimple;
import org.cloudsimplus.builders.tables.CloudletsTableBuilder;
import org.cloudsimplus.cloudlets.Cloudlet;
import org.cloudsimplus.cloudlets.CloudletSimple;
import org.cloudsimplus.core.CloudSimPlus;
import org.cloudsimplus.datacenters.Datacenter;
import org.cloudsimplus.datacenters.DatacenterSimple;
import org.cloudsimplus.hosts.Host;
import org.cloudsimplus.hosts.HostSimple;
import org.cloudsimplus.power.models.PowerModelHostSimple;
import org.cloudsimplus.resources.Pe;
import org.cloudsimplus.resources.PeSimple;
import org.cloudsimplus.schedulers.cloudlet.CloudletSchedulerTimeShared;
import org.cloudsimplus.utilizationmodels.UtilizationModelDynamic;
import org.cloudsimplus.vms.Vm;
import org.cloudsimplus.vms.VmSimple;

import java.util.ArrayList;
import java.util.List;

public class MiniDCExperiment {

    private static final int HOSTS = 2;
    private static final int HOST_PES = 8;
    private static final long HOST_MIPS = 1000;
    private static final long HOST_RAM = 32768;
    private static final long HOST_BW = 100000;
    private static final long HOST_STORAGE = 1000000;

    private static final int VMS = 6;
    private static final int VM_PES = 2;
    private static final long VM_RAM = 4096;
    private static final long VM_BW = 10000;
    private static final long VM_STORAGE = 20000;

    private static final int CLOUDLETS = 12;
    private static final long[] CLOUDLET_LENGTHS = {15000, 25000, 40000, 60000, 80000, 120000};

    public static void main(String[] args) {
        System.out.println("=== MiniDC Experiment - CloudSim Plus ===\n");

        runExperiment("VmAllocationPolicySimple (First-Fit)", new VmAllocationPolicySimple());
        runExperiment("VmAllocationPolicyRoundRobin", new VmAllocationPolicyRoundRobin());
    }

    private static void runExperiment(String policyName, Object allocationPolicy) {
        CloudSimPlus simulation = new CloudSimPlus();
        
        Datacenter datacenter = createDatacenter(simulation, allocationPolicy);
        DatacenterBroker broker = new DatacenterBrokerSimple(simulation);
        
        List<Vm> vmList = createVms();
        List<Cloudlet> cloudletList = createCloudlets();
        
        broker.submitVmList(vmList);
        broker.submitCloudletList(cloudletList);
        
        simulation.start();
        
        printMetrics(policyName, vmList, cloudletList, datacenter);
    }

    private static Datacenter createDatacenter(CloudSimPlus simulation, Object allocationPolicy) {
        List<Host> hostList = new ArrayList<>();
        
        for (int i = 0; i < HOSTS; i++) {
            List<Pe> peList = new ArrayList<>();
            for (int j = 0; j < HOST_PES; j++) {
                peList.add(new PeSimple(HOST_MIPS));
            }
            
            Host host = new HostSimple(HOST_RAM, HOST_BW, HOST_STORAGE, peList);
            host.setPowerModel(new PowerModelHostSimple(200, 100));
            host.enableUtilizationStats();
            hostList.add(host);
        }
        
        if (allocationPolicy instanceof VmAllocationPolicySimple) {
            return new DatacenterSimple(simulation, hostList, (VmAllocationPolicySimple) allocationPolicy);
        } else {
            return new DatacenterSimple(simulation, hostList, (VmAllocationPolicyRoundRobin) allocationPolicy);
        }
    }

    private static List<Vm> createVms() {
        List<Vm> vmList = new ArrayList<>();
        
        for (int i = 0; i < VMS; i++) {
            Vm vm = new VmSimple(HOST_MIPS, VM_PES);
            vm.setRam(VM_RAM).setBw(VM_BW).setSize(VM_STORAGE);
            vm.setCloudletScheduler(new CloudletSchedulerTimeShared());
            vmList.add(vm);
        }
        
        return vmList;
    }

    private static List<Cloudlet> createCloudlets() {
        List<Cloudlet> cloudletList = new ArrayList<>();
        
        UtilizationModelDynamic utilizationCpu = new UtilizationModelDynamic(0.85);
        UtilizationModelDynamic utilizationRam = new UtilizationModelDynamic(0.70);
        UtilizationModelDynamic utilizationBw = new UtilizationModelDynamic(0.50);
        
        for (int i = 0; i < CLOUDLETS; i++) {
            long length = CLOUDLET_LENGTHS[i % CLOUDLET_LENGTHS.length];
            Cloudlet cloudlet = new CloudletSimple(length, VM_PES);
            cloudlet.setUtilizationModelCpu(utilizationCpu);
            cloudlet.setUtilizationModelRam(utilizationRam);
            cloudlet.setUtilizationModelBw(utilizationBw);
            cloudletList.add(cloudlet);
        }
        
        return cloudletList;
    }

    private static void printMetrics(String policyName, List<Vm> vmList, List<Cloudlet> cloudletList, Datacenter datacenter) {
        double totalResponseTime = 0;
        double maxFinishTime = 0;
        
        for (Cloudlet cloudlet : cloudletList) {
            double responseTime = cloudlet.getStartTime() - cloudlet.getSubmissionDelay();
            totalResponseTime += responseTime;
            
            if (cloudlet.getFinishTime() > maxFinishTime) {
                maxFinishTime = cloudlet.getFinishTime();
            }
        }
        
        double avgResponseTime = totalResponseTime / cloudletList.size();
        double makespan = maxFinishTime;
        
        double totalEnergy = 0;
        for (Host host : datacenter.getHostList()) {
            double cpuUtilization = host.getCpuPercentUtilization();
            double power = host.getPowerModel().getPower(cpuUtilization);
            double energy = power * makespan;
            totalEnergy += energy;
        }
        
        double energyKwh = totalEnergy / 3600000.0;
        double availability = 100.0;
        
        System.out.printf("%s: AvgResponse=%.2f ms, Makespan=%.2f s, Energy=%.6f kWh, Availability=%.1f%%\n",
                policyName, avgResponseTime * 1000, makespan, energyKwh, availability);
    }
}
